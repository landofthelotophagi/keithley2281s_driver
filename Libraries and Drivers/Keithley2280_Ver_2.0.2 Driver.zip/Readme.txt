			***********************
			**** Read Me First ****
			***********************

Version 2.0
October 14, 2015


Introducing the Keithley IVI Driver for 2280 Series Precision Measurement DC Supplies and 2281 Series Precision DC Supply And Battery Simulator
-----------------------------------------------------------------------------------------------------------------------------------------------
The Keithley2280 IVI-COM/IVI-C driver conforms to the IVI driver standards and specifications. The help file included with the driver contains the detailed driver functionality description and programming information.
This readme file contains additional information for the user.
The driver uses the services provided by IVI Shared Components (provided by IVI Foundation) and VISA.
The driver can be used with GPIB or LAN or USB.

Supported Instruments
---------------------
Model 2280S-32-6
Model 2280S-60-3
Model 2281S-20-6
 
Installation
-------------
  System Requirements: The driver installation will check for the
  following requirements. If not found, the installer will either
  abort, warn, or install the required component as appropriate.

  Supported Operating Systems:
    Windows XP
    Windows Vista
    Windows 7
    Windows 8

  Shared Components
    Before this driver can be installed, your computer must already
    have the IVI Shared Components installed.

    Minimal IVI Version: 2.3

    The IVI Shared Components installer is available from: 
    http://www.ivifoundation.org/shared_components/Default.aspx


  VISA-COM
    The following implementations of VISA are compliant with this driver: NI-VISA�, AGILENT IO Libraries Suite�.
    The Keithley I/O Layer supplies a NI-VISA� runtime. Downloads are available at www.keithley.com/support or you may follow the link below:
    ( http://www.keithley.com/support/keidoc_searchresult?keyword=KIOL&item_type=Software+Driver ) 


Additional Setup
----------------
  .NET Framework
    The .NET Framework itself is not required by this driver. If you
    plan to use the driver with .NET, the minimal .NET framework version is 2.0.

    The .NET Framework requires an interop assembly for a COM
    server. A Primary Interop Assembly, along with an XML file for
    IntelliSense is installed with the driver. The driver's PIA, along
    with IVI PIAs are installed, by default, in:
    <drive>:\Program Files\IVI Foundation\IVI\Bin\Primary Interop Assemblies

    The PIA is also installed into the Global Assembly Cache (GAC) if
    you have the .NET framework installed.

Help File
---------
  The help file (Keithley2280.chm) is located in the directory:
   <drive>:\Program Files\IVI Foundation\IVI\Drivers\ke2280

Examples
--------
  The driver installs few examples written in C Sharp .NET and C++. Examples are located in the directory:
   <drive>:\Program Files\IVI Foundation\IVI\Drivers\ke2280\Examples 

IVI Compliance
--------------
IVI-COM/IVI-C Specific Instrument Driver
IVI Instrument Class: IviDCPwr
IviDCPwr: IVI-4.4_v3.0

IviDCPwrBase                    yes
IviDCPwrMeasurement             yes
IviDCPwrTrigger                 no
IviDCPwrSoftwaretrigger         yes

Optional Features:
----------------- 
Interchangeability Checking     no
State Caching                   no
Coercion Recording              no
Simulation                      no

Driver Identification:
--------------------- 
Vendor:                         Keithley. 
Description:                    IVI Driver for Keithley 2280 Series Precision Measurement DC Supplies and 2281 Series Precision DC Supply And Battery Simulators
Revision:                       2.0
Component Identifier:           Keithley2280
IVI-C prefix: 			ke2280

Hardware Information:
--------------------
Instrument Manufacturer:        Keithley Instruments
Supported Instrument Models:    Model 2280S-32-6, Model 2280S-60-3, Model 2281S-20-6
Supported Bus Interfaces:       GPIB, LAN, USB

32-bit Software Information:
---------------------------
Supported Operating Systems:    Windows XP, Windows Vista, Windows 7, Windows 8
Support Software Required:      VISA
Source Code Availability:       Source code included with driver.

64-bit Software Information:
---------------------------
Supported Operating Systems: 	Windows Vista, Windows 7, Windows 8  
Support Software Required:      VISA
Source Code Availability:       Source code included with driver.


Revision History
----------------
Revision version: 1.0
Date: August 1, 2014 - Initial public release

Revision version:2.0.2
Date: October 14, 2015

Added Support to 2281S-20-6 Precision DC Supply And Battery Simulator.

1. Following new interfaces are added

Interface Name : IKeithley2280Battery added to IKeithley2280 Interface
Properties: OutputState, OutputProtectionTripped
Methods: ResetOutputProtection

Interface Name : IKeithley2280BatterySimulator added to IKeithley2280Battery Interface
Properties: SimulationMode, CapacityLimit, ResistanceOffset, CurrentLimit, OVPLimit, OCPLimit, StateOfCharge, OpenCircuitVoltage, OpenCircuitVoltageFull, OpenCircuitVoltageEmpty, Resistance, Capacity, Current, TerminalVoltage
Methods: ConfigureSettings

Interface Name : IKeithley2280BatteryTest added to IKeithley2280Battery Interface

Interface Name : IKeithley2280BatteryTestSource added to IKeithley2280BatteryTest Interface
Properties: VoltageLevel, VoltageLimit, SourceCurrentLimit, DischargeCurrentLimit, EndCurrent, OVPLimit, OCPLimit

Interface Name : IKeithley2280BatteryTestMeasure added to IKeithley2280BatteryTest Interface
Properties: SampleInterval, ESRIntervalInAH, EVOCDelay, Capacity, FullVoltageInAH, CurrentLimitInAH, AHMeasurementState
Methods: MeasureEVOC, ConfigureAHMeasurement, GenerateBatteryModel

Interface Name : IKeithley2280BatteryModel added to IKeithley2280Battery Interface
Methods: CreateModel, EditModel, QueryModel, RecallByModelIndex, RecallByBuildInModel, Save, SaveToUSB, LoadFromUSB

2. Following new Properties/Methods are added to the existing Interfaces.

Interface Name : IKeithley2280System
Properties: OperationMode

NOTE:
-----
Battery Test and Battery Simulator functionalities are not applicable for 2280 series models.
If 2280 series model instrument access below interfaces will get "Instrument model does not support this feature" error message.
IKeithley2280Battery
IKeithley2280BatterySimulator
IKeithley2280BatteryTest
IKeithley2280BatteryTestSource
IKeithley2280BatteryTestMeasure
IKeithley2280BatteryModel
